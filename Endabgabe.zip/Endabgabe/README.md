# Eisdealer_EIA2_Endprojekt
EIA2 Endprojekt: Interaktives Eiscafe Game mit Typescript
