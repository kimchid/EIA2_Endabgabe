"use strict";
var Eisdealer;
(function (Eisdealer) {
    class Vector {
        x;
        y;
        constructor(x, y) {
            this.x = x;
            this.y = y;
        }
    }
    Eisdealer.Vector = Vector;
})(Eisdealer || (Eisdealer = {}));
//# sourceMappingURL=Vector.js.map