namespace Eisdealer {
    export class Vector {
        constructor(public x: number, public y: number) { }
    }
}
