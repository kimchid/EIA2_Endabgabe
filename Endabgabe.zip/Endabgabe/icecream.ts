// IceCreamItems.ts
namespace Eisdealer {
    export interface IceCreamItem {
        name: string;
        price: number;
    }

    export const iceCreamItems: IceCreamItem[] = [
        { name: 'Schokolade', price: 2 },
        { name: 'Erdbeere', price: 2 },
        { name: 'Vanille', price: 2 },
        { name: 'Pistazie', price: 2 }
    ];
}
