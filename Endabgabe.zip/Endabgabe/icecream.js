"use strict";
// IceCreamItems.ts
var Eisdealer;
(function (Eisdealer) {
    Eisdealer.iceCreamItems = [
        { name: 'Schokolade', price: 2 },
        { name: 'Erdbeere', price: 2 },
        { name: 'Vanille', price: 2 },
        { name: 'Pistazie', price: 2 }
    ];
})(Eisdealer || (Eisdealer = {}));
//# sourceMappingURL=icecream.js.map