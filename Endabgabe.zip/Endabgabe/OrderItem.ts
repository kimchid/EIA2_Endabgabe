namespace Eisdealer {
export interface OrderItem {
    name: string;
    quantity: number;
    price: number;}
  
// export const OrderItems: OrderItem[] = [
//         { name: 'Schokolade', quantity: 2, price: 2 },
//         { name: 'Erdbeere', quantity: 2, price: 2 },
//         { name: 'Vanille', quantity: 3, price: 2 },
//         { name: 'Pistazie', quantity: 4, price: 2 }];
}